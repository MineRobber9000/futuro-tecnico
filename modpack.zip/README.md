# Futuro T&eacute;cnico
A cybre-futuristic tech pack. Aims to be tech-based and small. 1.12.

Mod list: https://khuxkm.tilde.team/ftmodpack/modlist.php
